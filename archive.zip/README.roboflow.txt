
sibi_spik - v1 20210608 650pm
==============================

This dataset was exported via roboflow.ai on June 8, 2021 at 12:01 PM GMT

It includes 1323 images.
A are annotated in Pascal VOC format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


